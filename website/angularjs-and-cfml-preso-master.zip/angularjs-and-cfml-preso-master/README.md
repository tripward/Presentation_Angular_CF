# angularjs-and-cfml-preso
"Connecting AngularJS and ColdFusion" presentation files

This repo contains the Slides and Sample files.

To get the CFM files to run you need a CFML server.
The easiest way to do this is use CommandBox; we have 
box.json and server.json files configured in here that 
make all the setup automatic.

1. Install CommandBox
2. Run "box install"
3. Run "box server start"

